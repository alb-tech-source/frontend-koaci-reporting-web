export interface User {
  id: string;
  firstname: string;
  lastname: string;
  email: string;
  role_name: string;
  permission_ids: string[];
  is_active: boolean;
}

export type UserFormValues = Omit<User, "id">;