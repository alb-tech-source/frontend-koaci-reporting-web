import api from "@/shared/lib/axios";
import type { User, UserFormValues } from "./types";

export async function fetchUsers(page: number, limit = 10) {
  const { data } = await api.get(`/users?page=${page}&limit=${limit}`);
  return data;
}

export async function fetchUserById(id: string) {
  const { data } = await api.get<User>(`/users/${id}`);
  return data;
}

export async function createUser(payload: UserFormValues) {
  const { data } = await api.post("/users/", payload);
  return data;
}

export async function updateUser(id: string, payload: UserFormValues) {
  const { data } = await api.put(`/users/${id}`, payload);
  return data;
}

export async function deleteUser(id: string) {
  await api.delete(`/users/${id}`);
}

export async function toggleUserActivation(id: string, isActive: boolean) {
  const { data } = await api.patch(`/users/${id}/activate`, { isActive });
  return data;
}